"use strict";
import Result from "./result.js";
import { formatInput } from "./utilities/input-format.js";
import { Popup } from "./utilities/popup.js";

const PHYSICAL_ACTIVITY_RATIO = {
    MIN: 1.2,
    LOW: 1.375,
    MEDIUM: 1.55,
    HIGH: 1.725,
    MAX: 1.9
};

const CALORIES_FORMULA_FACTOR = {
    WEIGHT: 10,
    HEIGHT: 6.25,
    AGE: 5
};

const CALORIES_FORMULA_CONSTANT = {
    MALE: 5,
    FEMALE: -161
};

const CALORIES_GAIN_LOSS_RATIO = {
    LOSS: 0.85,
    GAIN: 1.15
};

export default class Counter {
    constructor(element){
        this.rootNode = element;
        this.form = this.rootNode.querySelector('.counter__form');
        this.elements = this.form.elements;
        this.parameters = this.elements.userParameters.elements;
        this.activity = this.elements.activity;
        this.age = this.elements.age;
        this.gender = this.elements.gender;
        this.weight = this.elements.weight;
        this.height = this.elements.height;
        this.submitBtn = this.elements.submit;
        this.clearBtn = this.elements.reset;

        this.result = new Result(this.rootNode);

        this.parametersItems = Array.from(this.parameters);

        this._onFormInput = this._onFormInput.bind(this);
        this._onFormReset = this._onFormReset.bind(this);
        this._onFormSubmit = this._onFormSubmit.bind(this);
    }

    init() {
        this.form.addEventListener('input', this._onFormInput);
        this.form.addEventListener('submit', this._onFormSubmit);
        this.form.addEventListener('reset', this._onFormReset);
    }


    _onFormInput() {
        this.submitBtn.disabled = !this.form.checkValidity();                                            // Returns false if an form contains valid data
        this.age.value = formatInput(this.age);
        this.height.value = formatInput(this.height);
        this.weight.value = formatInput(this.weight);

        this.clearBtn.disabled = !this.parametersItems.some((el) => { return el.value !== ""; });        // Returns true if at least one form element contains data  
        
    }

    _onFormReset() {
        this.submitBtn.disabled = true;
        this.clearBtn.disabled = true;
        this.result.hide();
    }

    _onFormSubmit(event) {
        event.preventDefault();

        const caloriesResultData = {
            norm: this.getCaloriesNorm(),
            min: this.getCaloriesMin(),
            max: this.getCaloriesMax()
        };

        this.result.show(caloriesResultData);
    }

    getCaloriesNorm() {
        if(!this.checkPhysicalParameters(this.parametersItems)) return 0;

        const weight = CALORIES_FORMULA_FACTOR.WEIGHT * this.weight.value;
        const height = CALORIES_FORMULA_FACTOR.HEIGHT * this.height.value;
        const age = CALORIES_FORMULA_FACTOR.AGE * this.age.value;
        const gender = CALORIES_FORMULA_CONSTANT[this.gender.value.toUpperCase()];
        const activity = PHYSICAL_ACTIVITY_RATIO[this.activity.value.toUpperCase()];

        return Math.round((weight + height - age + gender) * activity);
    }

    getCaloriesMin() {
        return Math.round(this.getCaloriesNorm() * CALORIES_GAIN_LOSS_RATIO.LOSS);
    }

    getCaloriesMax() {
        return Math.round(this.getCaloriesNorm() * CALORIES_GAIN_LOSS_RATIO.GAIN);
    }

    checkPhysicalParameters(parameters){
        console.log(parameters);
        if (!(parameters[0].value >= 13 && parameters[0].value <= 80)) {
            Popup.fire({
                icon: "warning",
                title: "Age must be between 13 and 80"
            });
            return false;
        }

        if (!(parameters[1].value >= 140 && parameters[1].value <= 210)) {
            Popup.fire({
                icon: "warning",
                title: "Height must be between 140 and 210"
            });
            return false;
        }

        if (!(parameters[2].value >= 30 && parameters[2].value <= 200)) {
            Popup.fire({
                icon: "warning",
                title: "Weight must be between 30 and 200"
            });
            return false;
        }
        return true;
    }
}


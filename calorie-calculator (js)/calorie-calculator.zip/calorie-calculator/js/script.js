"use strict";
import Counter from './modules/counter.js';

let counters = document.querySelectorAll('.counter'); 

counters.forEach((element) => {
    const counter = new Counter(element);
    counter.init();
});

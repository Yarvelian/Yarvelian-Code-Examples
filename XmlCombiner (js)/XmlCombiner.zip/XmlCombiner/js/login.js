 "use strict";

    jQuery(document).ready(function(){
      jQuery('#login-form').submit(function(){
          var data = jQuery('#login-form').serialize();
          console.log(data);
          jQuery.ajax({
            url: 'login.php',
            type: 'POST',
            data: data,
            success: function(res){
              if( res == true ){
                data = ''; 
                console.log("Заявка успішно відправлена!","Дякуємо! Вам дадуть відповідь в найкоротший час", "success");
              }else if(res == false) {
                
                console.log("Помилка відправки (сервер)" ,"", "error");
              
              }
            },
            error: function(){
              console.log("Помилка відправки (скрипт)","", "error");
            }
          });
        
      
        return false;
      });
      
      });

  
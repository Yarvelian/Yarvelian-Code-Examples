"use strict";

const btnCopyReference = document.querySelector(".btn-copy"),
referenceText = document.querySelector(".reference"),
copyTooltip = document.querySelector(".tooltip-custom"),
btnAddWidget = document.querySelector(".btn-add-widget"),
mainForm = document.getElementById("main-form");

let widgetCounter = 0;
let template = document.querySelector('#template-widget');
let templateCoef = document.querySelector('#template-coef');

let coefArray = [];

function deleteWidget(id){
    let searchId = parseInt(id.split('-')[1]);
    document.querySelector(`#widget-${searchId}`).remove();
    widgetCounter--;
}

function addCoefficient(id){
    let searchId = parseInt(id.split('-')[1]);
    let coefContainer = document.querySelector(`#coefContainer-${searchId}`);
    
    coefArray[searchId - 1]++;
    templateCoef.content.querySelector('.quantity').setAttribute("name", `quantity-${coefArray[searchId - 1]}`);
    templateCoef.content.querySelector('.wholesaleCoef').setAttribute("name", `wholesaleCoef-${coefArray[searchId - 1]}`);
    let clone = document.importNode(templateCoef.content, true);
    coefContainer.prepend(clone);
}

function deleteCoefficient(id){
    let searchId = parseInt(id.split('-')[1]);
    let coefContainer = document.querySelector(`#coefContainer-${searchId}`);
    if (coefContainer.children.length > 0){
        coefContainer.firstElementChild.remove();
        coefArray[searchId - 1]--;
    }
}


//Copy reference to clipboard and show the tooltip
btnCopyReference.addEventListener("click", function(){
    referenceText.select();
    document.execCommand("copy");

    copyTooltip.classList.toggle("copied");
});

btnCopyReference.addEventListener("mouseleave", function(){
    copyTooltip.classList.remove("copied");
});

//Clone new reference template
btnAddWidget.addEventListener("click", function (){
    if ('content' in template) {
        widgetCounter++;

        template.content.querySelector('.new-reference').setAttribute("id", `widget-${widgetCounter}`);

        template.content.querySelector('.custom-control-input').setAttribute("id", `checkbox-${widgetCounter}`);
        template.content.querySelector('.custom-control-label').setAttribute("for", `checkbox-${widgetCounter}`);

        template.content.querySelector('[name = "retailCoef[]"]').setAttribute("id", `retailCoef-${widgetCounter}`);
        template.content.querySelector(".btnMinus").setAttribute("id", `btnMinus-${widgetCounter}`);
        template.content.querySelector(".btnPlus").setAttribute("id", `btnPlus-${widgetCounter}`);
        template.content.querySelector('.coef-container').setAttribute("id", `coefContainer-${widgetCounter}`);
        template.content.querySelector('[name = "btnDelete"]').setAttribute("id", `btnDelete-${widgetCounter}`);

        let cloneMain = document.importNode(template.content, true);
        mainForm.prepend(cloneMain);

        coefArray.push(0);

    } else {
        console.log("yasno, hueta");
    }
});







<!DOCTYPE html>
<html lang="ru">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Xml Combiner</title>
    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">
    <!-- Main css -->
    <link rel="stylesheet" href="css/style.css">
</head>

<body>
    <div style="display:none;">
        <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
            <symbol id="reference-icon" viewBox="0 0 24 24">
                <path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71">
                </path>
                <path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71">
                </path>
            </symbol>
            <symbol id="icon-plus" viewBox="0 0 24 24">
                <line x1="12" y1="5" x2="12" y2="19"></line>
                <line x1="5" y1="12" x2="19" y2="12"></line>
            </symbol>
            <symbol id="icon-minus" viewBox="0 0 24 24">
                <line x1="5" y1="12" x2="19" y2="12"></line>
            </symbol>
            <symbol id="icon-delete" viewBox="0 0 24 24">
                <polyline points="3 6 5 6 21 6"></polyline>
                <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2">
                </path>
                <line x1="10" y1="11" x2="10" y2="17"></line>
                <line x1="14" y1="11" x2="14" y2="17"></line>
            </symbol>

        </svg>
    </div>

    <header id="topnav" class="bg-light">
        <nav>
            <div class="container d-flex justify-content-center">
                <img src="logo-main.png" alt="logo" height="90px" width="190px">
            </div>
        </nav>

    </header>
    <!--end header-->
    <section class="bg-half bg-light d-table w-100">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-12 text-center">
                    <div class="page-next-level">
                        <h4 class="title"> Добро пожаловать, <span class="login-text">Yarvelian.</span></h4>
                        <div class="page-next">
                            <div class="container">
                                <div class="row justify-content-center">
                                    <div class="col-lg-8">
                                        <div class="card public-profile border-0 rounded shadow" style="z-index: 1;">
                                            <div class="card-body script-reference">
                                                <h2 class="reference-title">Ссылка на скрипт:</h2>
                                                <div class="row">
                                                    <div class="col-12  reference-col ">
                                                        <input type="text" value="https://www.w3schools.com/"
                                                            class="reference" readonly="readonly">

                                                        <button class="btn-copy">
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="24"
                                                                height="24" viewBox="0 0 24 24" fill="none"
                                                                stroke="currentColor" stroke-width="2"
                                                                stroke-linecap="round" stroke-linejoin="round"
                                                                class="feather feather-copy">
                                                                <rect x="9" y="9" width="13" height="13" rx="2" ry="2"
                                                                    fill="none"></rect>
                                                                <path
                                                                    d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"
                                                                    fill="none"></path>
                                                            </svg>
                                                        </button>
                                                        <div class="tooltip-custom">
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!--end col-->
                                </div>
                                <!--end row-->
                            </div>
                            <!--ed container-->
                        </div>
                    </div>
                </div>
                <!--end col-->
            </div>
            <!--end row-->
        </div>
        <!--end container-->

    </section>
    <!--end section-->
    <div class="position-relative">
        <div class="shape overflow-hidden text-white">
            <svg viewBox="0 0 2880 48" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M0 48H1437.5H2880V0H2160C1442.5 52 720 0 720 0H0V48Z" fill="currentColor"></path>
            </svg>
        </div>
    </div>

    <section class="section mt-60 section-main">
        <div class="container mt-lg-3">
            <div class="row">
                <div class="col-lg-4 col-md-6 col-12 d-lg-block d-none">
                    <div class="sidebar p-4 rounded shadow">
                        <div class="widget">
                            <h5 class="widget-title">Управление :</h5>
                            <div class="row mt-4">

                            </div>
                            <!--end row-->
                        </div>


                        <div class="widget">
                            <div class="row justify-content-center mt-2">
                                <div class="col-md-8 d-flex justify-content-center">
                                    <input type="submit" form="main-form" class="btn btn-submit" value="Объединить">
                                </div>
                                <div class="col-6 mt-4 pt-2">
                                    <a href="#" class="panel rounded d-block shadow text-center py-3">
                                        <div class="icon">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24"
                                                viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"
                                                stroke-linecap="round" stroke-linejoin="round"
                                                class="feather feather-help-circle">
                                                <circle cx="12" cy="12" r="10"></circle>
                                                <path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"></path>
                                                <line x1="12" y1="17" x2="12.01" y2="17"></line>
                                            </svg>
                                        </div>
                                        <h6 class="title h6 my-0">Помощь</h6>
                                    </a>
                                </div>
                                <!--end col-->

                                <div class="col-6 mt-4 pt-2">
                                    <a href="#" class="panel rounded d-block shadow text-center py-3">
                                        <div class="icon">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24"
                                                viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"
                                                stroke-linecap="round" stroke-linejoin="round"
                                                class="feather feather-log-out">
                                                <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"></path>
                                                <polyline points="16 17 21 12 16 7"></polyline>
                                                <line x1="21" y1="12" x2="9" y2="12"></line>
                                            </svg>
                                        </div>
                                        <h6 class="title h6 my-0">Выход</h6>
                                    </a>
                                </div>
                                <!--end col-->
                            </div>
                            <!--end row-->
                        </div>

                    </div>
                </div>
                <!--end col-->

                <div class="col-lg-8 col-12">
                    <div class="card border-0 rounded shadow right-card">
                        <div class="card-body">
                            <div class="d-flex align-items-center justify-content-between mb-4">
                                <h5 class="mb-0">Xml-ссылки :</h5>
                                <button  data-toggle="modal" data-target="#addnewcard" class="btn btn-add-widget">
                                    <svg class="feather fea icon-sm icons feather-link" width="24" height="24"
                                        stroke="currentColor" stroke-width="2" stroke-linecap="round"
                                        stroke-linejoin="round" fill="none">
                                        <use xlink:href="#icon-plus" x="0" y="0"></use>
                                    </svg>
                                    Добавить
                                </button>
                            </div>
                            <div class="references-container">
                                <form action="" id="main-form" method="GET">
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                <!--end col-->
            </div>
            <!--end row-->
        </div>
        <!--end container-->
    </section>
    <!--end section-->
    <section class="section__table">
        <div class="container">
            <div class="row justify-content-center">

                <div class="col-md-11">
                    <!-- Table Start -->
                    <div class="col-md-12 d-flex justify-content-center">
                        <h3 class="section__table__title mb-4">Таблица текущих ссылок</h3>
                    </div>

                    <div class="p-4">
                        <div class="table-responsive bg-white shadow rounded">
                            <table class="table mb-0 table-center">
                                <col width="50">
                                <col width="200">
                                <col width="100">
                                <col width="100">
                                <thead>
                                    <tr>
                                        <th scope="col">#</th>
                                        <th scope="col">Ссылка</th>
                                        <th scope="col">Примечание</th>
                                        <th scope="col">Удалить</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <th scope="row">1</th>
                                        <td nowrap><a
                                                href="http://example.net/xmlxslt/examples/xsl/ex01-1.xml">http://example.net/xmlxslt/examples/xsl/ex01-1.xml</a>
                                        </td>
                                        <td>ТОВ Полярная Звезда</td>
                                        <td>
                                            <button class="btn py-1 px-2 ml-3">
                                                <svg class="feather feather-trash-2" width="20" height="20" fill="none"
                                                    stroke="currentColor" stroke-width="2" stroke-linecap="round"
                                                    stroke-linejoin="round">
                                                    <use xlink:href="#icon-delete" x="0" y="0"></use>
                                                </svg>
                                            </button>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th scope="row">2</th>
                                        <td nowrap><a
                                                href="http://example.net/xmlxslt/examples/xsl/ex01-1.xml">http://example.net/xmlxslt/examples/xsl/ex01-1.xml</a>
                                        </td>
                                        <td>ООО ВТБ</td>
                                        <td>
                                            <button class="btn py-1 px-2 ml-3">
                                                <svg class="feather feather-trash-2" width="20" height="20" fill="none"
                                                    stroke="currentColor" stroke-width="2" stroke-linecap="round"
                                                    stroke-linejoin="round">
                                                    <use xlink:href="#icon-delete" x="0" y="0"></use>
                                                </svg>
                                            </button>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th scope="row">3</th>
                                        <td nowrap><a
                                                href="http://example.net/xmlxslt/examples/xsl/ex01-1.xml">http://example.net/xmlxslt/examples/xsl/ex01-1.xml</a>
                                        </td>
                                        <td>ТМ Крейн</td>
                                        <td> <button class="btn py-1 px-2 ml-3">
                                                <svg class="feather feather-trash-2" width="20" height="20" fill="none"
                                                    stroke="currentColor" stroke-width="2" stroke-linecap="round"
                                                    stroke-linejoin="round">
                                                    <use xlink:href="#icon-delete" x="0" y="0"></use>
                                                </svg>
                                            </button></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </section>

    </footer>
    <!--end footer-->
    <footer class="footer footer-bar">
        <div class="container text-center">
            <div class="row align-items-center">
                <div class="col-sm-12">
                    <div class="text-sm-center">
                        <p class="mb-0">All rights reserved.<br>
                            Design & Front-end by <a href="https://t.me/Yarvelian" target="_blank"
                                class="text-reset">Yarvelian</a> <br>
                            Back-end by <a href="#" target="_blank" class="text-reset">Anton Kravets</a>
                        </p>
                    </div>
                </div>
                <!--end col-->
            </div>
            <!--end row-->
        </div>
        <!--end container-->
    </footer>
    <!--end footer-->
    <!-- Footer End -->
    <template id="template-widget">
        <div class="card new-reference border-0 rounded shadow mb-4">
            <div class="card-body">
                <div class="row">
                    <div class="col-md-12">
                        <div class="form-group position-relative">
                            <label>Ссылка на документ: <span
                                    class="text-danger">*</span></label>
                            <svg class="fea icon-sm icons" width="24"
                                height="24" stroke="currentColor" stroke-width="2"
                                stroke-linecap="round" stroke-linejoin="round" fill="none">
                                <use xlink:href="#reference-icon" x="0" y="0"></use>
                            </svg>
                            <input name="reference[]"  type="text"
                                class="form-control pl-5"
                                placeholder="http://example.net/xmlxslt/examples/xsl/ex01-1.xml"
                                form="main-form" required="" onkeyup="this.setAttribute('value', this.value);" value="">
                        </div>
                    </div>
                    <!--end col-->

                    <div class="col-md-6">
                        <div class="form-group position-relative">
                            <label>Примечание к ссылке: </label>
                            <input name="linkName[]" type="text" class="form-control"
                                placeholder='ТОВ "Полярная Звезда"' form="main-form" onkeyup="this.setAttribute('value', this.value);" value="">
                        </div>
                    </div>
                    <!--end col-->

                    <div class="col-md-6 d-flex align-items-center pl-5">
                        <div class="form-group position-relative ">
                            <div class="custom-control custom-checkbox">
                                <input name="checkbox[]" type="checkbox" class="custom-control-input"
                                     form="main-form">
                                <label class="custom-control-label">Перемешать фотографии</label>
                            </div>
                        </div>
                    </div>
                    <!--end col-->

                    <div class="col-md-5 position-relative">
                        <div class="form-group position-relative">
                            <label class="mb-3">Коеф. розничной цены: </label>
                            <input name="retailCoef[]" type="number" step="0.25"
                                class="form-control" value="1" form="main-form">
                        </div>
                    </div>
                    <!--end col-->
                    <div class="col-md-6 ml-5 position-relative">
                        <div class="form-group position-relative">
                            <!--class="feather feather-plus fea icon-sm">-->
                            <div class="d-flex align-items-center mb-2">
                                <label>Коеф. оптовых цен: </label>
                                <button class="btn btn-add ml-5 btnMinus" type="button" onclick="deleteCoefficient(this.id)" >
                                    <svg class="feather feather-plus fea icon-sm" width="24"
                                        height="24" fill="none" stroke="currentColor"
                                        stroke-width="2" stroke-linecap="round"
                                        stroke-linejoin="round">
                                        <use xlink:href="#icon-minus" x="0" y="0"></use>
                                    </svg>
                                </button>
                                <button class="btn btn-add ml-2 btnPlus" type="button" onclick="addCoefficient(this.id)">
                                    <svg class="feather feather-plus fea icon-sm" width="24"
                                        height="24" fill="none" stroke="currentColor"
                                        stroke-width="2" stroke-linecap="round"
                                        stroke-linejoin="round">
                                        <use xlink:href="#icon-plus" x="0" y="0"></use>
                                    </svg>
                                </button>
                            </div>
                            <div class="coef-container"></div>


                        </div>
                    </div>
                    <!--end col-->

                    <div class="col-md-12 d-flex justify-content-center mt-3">
                        <button class="btn btn-delete" name="btnDelete" type="button" onclick="deleteWidget(this.id)">
                            <svg class="feather feather-trash-2" width="20" height="20"
                                fill="none" stroke="currentColor" stroke-width="2"
                                stroke-linecap="round" stroke-linejoin="round">
                                <use xlink:href="#icon-delete" x="0" y="0"></use>
                            </svg>
                            Удалить
                        </button>
                    </div>
                </div>

            </div>
        </div>
    </template>
    <template id="template-coef">
    <div class="new-coef d-flex mb-3">
        <div class="col-md-6">
            <input type="text"
                class="form-control quantity" placeholder="Количество"
                form="main-form" pattern="^[ 0-9]+$" onkeyup="this.setAttribute('value', this.value);" value="" required>
        </div>
        <div class="col-md-6">
            <input type="number" step="0.25"
                 class="form-control wholesaleCoef" value="1"
                form="main-form">
        </div>
    </div>
    </template>
    <script src="js/main.js"></script>
</body>

</html>
<?php 
        if (isset($_POST["login"]) && ($_POST["login"] = "IrinaKravets")){
            if (isset($_POST["password"] && ($_POST["password"] = "123321"))){
                $_SESSION["user"] = "Irina";
                header('Location: index.html');
                exit;
            }
        }

        exit(true);
?>